#include"udf.h"
DEFINE_PROFILE(inlet_x_velocity, t, position)
{
face_t f;
real flow_time = RP_Get_Real("flow-time");
int i = (int)(flow_time/3.0)%2;
begin_f_loop(f, t)
{

if(i)
F_PROFILE(f,t ,position)=0;
else
F_PROFILE(f,t,position)=0.58425;
}
end_f_loop(f, t)
}