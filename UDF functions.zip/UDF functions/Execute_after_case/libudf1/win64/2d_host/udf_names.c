/* This file generated automatically. */ 
/* Do not modify. */ 
#include "udf.h" 
#include "prop.h" 
#include "dpm.h" 
extern DEFINE_EXECUTE_AFTER_CASE(after_case,libudf);
extern DEFINE_EXECUTE_AFTER_DATA(after_data,libudf);
__declspec(dllexport) UDF_Data udf_data[] = { 
{"after_case", (void (*)(void))after_case, UDF_TYPE_EXECUTE_AFTER_CASE},
{"after_data", (void (*)(void))after_data, UDF_TYPE_EXECUTE_AFTER_DATA},
}; 
__declspec(dllexport) int n_udf_data = sizeof(udf_data)/sizeof(UDF_Data); 
#include "version.h" 
__declspec(dllexport) void UDF_Inquire_Release(int *major, int *minor, int *revision) 
{ 
*major = RampantReleaseMajor; 
*minor = RampantReleaseMinor; 
*revision = RampantReleaseRevision; 
} 
