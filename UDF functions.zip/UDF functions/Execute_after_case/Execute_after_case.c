#include"udf.h"
DEFINE_EXECUTE_AFTER_CASE(after_case,libudf)
{
Message("\nEXECUTE_AFTER_CASE is read from %s library\n",libudf);
}
DEFINE_EXECUTE_AFTER_DATA(after_data,libudf)
{
Message("\nEXECUTE_AFTER_DATA is read from %s library\n",libudf);
}
