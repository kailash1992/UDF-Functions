#include"udf.h"
DEFINE_ON_DEMAND(on_demand_calc)
{
real tmin=0.;
real tmax=0.;
real tavg=0.;
real temp,volume,vol_tot=0.;
Domain *d;
Thread *t;
cell_t c;
d=Get_Domain(1);
thread_loop_c(t,d)
{
begin_c_loop(c,t)
{
volume=C_VOLUME(c,t);
temp=C_T(c,t);
if(temp<tmin || tmin==0.)
temp=tmin;
if(temp>tmax || tmax==0.)
temp=tmax;
vol_tot+=volume;
tavg+=volume*temp;
}
end_c_loop(c,t)
tavg/=vol_tot;
printf("\n Tmin=%g Tmax=%g Tavg=%g\n",tmin,tmax,tavg);
begin_c_loop(c,t)
{
temp=C_T(c,t);
C_UDMI(c,t,0)=(temp-tmin)/(tmax-tmin);
}
end_c_loop(c,t)
}
}



