#include"udf.h"
#include"mem.h"
#define NUM_UDM 3
int udm_offset=UDM_UNRESERVED;
DEFINE_EXECUTE_ON_LOADING(on_loading,libudf)
{
if(udm_offset==UDM_UNRESERVED)
udm_offset=Reserve_User_Memory_Vars(NUM_UDM);
if(udm_offset==UDM_UNRESERVED)
Message("\nMemory is not reserved yet, you need to define upto %d extra UDM's in the GUI and then reload the current library %s\n",NUM_UDM,libudf);
else
{
Set_User_Memory_Name(udm_offset,"UDM_0");
Set_User_Memory_Name(udm_offset+1,"UDM_1");
Set_User_Memory_Name(udm_offset+2,"UDM_2");
}
Message("\noffset for currently loaded library:%d",udm_offset);
}
DEFINE_ON_DEMAND(set_udms)
{
Domain *d;
Thread *t;
cell_t c;
int i;
d=Get_Domain(1);
if(udm_offset!=UDM_UNRESERVED)
{
for(i=0;i<NUM_UDM;i++)
{
thread_loop_c(t,d)
{
begin_c_loop(c,t)
{
C_UDMI(c,t,udm_offset+i)=3.0+i/10.0;
}
end_c_loop(c,t)
}
}
}
else
Message("UDM's have not yet been reserved\n");
}





