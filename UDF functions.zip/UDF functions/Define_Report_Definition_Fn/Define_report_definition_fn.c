#include"udf.h"
DEFINE_REPORT_DEFINITION_FN(Vol_flow_rate)
{
real vel_inlet=Get_Input_Parameter("velocity_inlet");
real inlet_area=0.015;
real vol_flow=vel_inlet*inlet_area;
return vol_flow;
}


