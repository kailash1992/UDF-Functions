#include"udf.h"
int release=1;
int version=2;
DEFINE_EXECUTE_ON_LOADING(vesion_status,libudf)
{
Message("\nloading %s version %d.%d\n",libudf,release,version);
}