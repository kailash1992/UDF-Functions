#include"udf.h"
DEFINE_INIT(my_init_func,d)
{
cell_t c;
Thread *t;
real xc[ND_ND];
thread_loop_c(t,d)
{
begin_c_loop_all(c,t)
{
C_CENTROID(xc,c,t);
if(sqrt(ND_SUM(pow(xc[0]-0.5,2.),pow(xc[1]-0.5,2.)))<0.25)
C_T(c,t)=700;
else
C_T(c,t)=800;
}
end_c_loop_all(c,t)
}
}
